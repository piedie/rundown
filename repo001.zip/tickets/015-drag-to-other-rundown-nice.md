# Ticket 015 — Drag item naar andere rundown vanuit overzicht (nice-to-have)

## DOEL
Item vanuit editor/overview slepen naar een andere rundown.

## SCOPE
- Rundown sidebar toont andere rundowns als droptarget
- Drag item -> drop op rundown -> move/copy keuze
- Valideer rechten

## ACCEPTATIECRITERIA
- Drop werkt zonder dat itemdata verloren gaat
- Fallback: als drag niet kan, is contextmenu (Ticket 014) voldoende

