# Versioning strategy

Format: v0.<milestone>.<patch> - <builddatum> <buildtijdstip>
- ook builddatum tonen!

Milestones:
- 0.1 = bootstrap + auth
- 0.2 = programs + memberships
- 0.3 = rundowns CRUD
- 0.4 = editor blocks + items
- 0.5 = timing + warnings + checks
- 0.6 = collaboration + audit
- 0.7 = audio assets
- 0.8 = sub-rundowns
- 0.9 = run-mode light

Na acceptatie:
- v1.0.0 = productie-release

- ook builddatum tonen!