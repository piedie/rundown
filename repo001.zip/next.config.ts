v0.1.0 - 2026-01-28 00:00
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {}
};

export default nextConfig;
