# Ticket checklist

- [ ] Docker build succeeds
- [ ] App starts without errors
- [ ] Permissions enforced server-side
- [ ] UI matches spec
- [ ] Version updated in /VERSION
- [ ] Footer shows correct version
- [ ] Manual test steps documented
