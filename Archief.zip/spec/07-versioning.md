# Versioning

- Version format: v0.<milestone>.<patch>
- VERSION file is the single source for the running app version
- Footer must show current version on every screen

Rules
- Every ticket increments patch (or milestone if big)
- Audit events include app_version

Example
- v0.4.1
